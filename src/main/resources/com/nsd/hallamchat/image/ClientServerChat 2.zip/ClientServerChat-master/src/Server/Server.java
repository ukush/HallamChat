package Server;

import Message.Message;
import org.json.simple.JSONValue;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.stream.Collectors;

public class Server {

//----------------------------------- Channel -------------------------------------------------//
    static class Channel {
    private static final String _class
            = Channel.class.getSimpleName();

    private String name;

    // list of messages from clients
    private ArrayList<Message> messages = new ArrayList<>();

    // list of subscribed users (name only)
    private ArrayList<String> subscribers = new ArrayList<>();

    private HashMap<String, Integer> messagesRead = new HashMap<>();

    // constructor
    public Channel(String name) {

        this.name = name;
        subscribers.add(name); // add user to subscriber list
    }

    public synchronized void addMessage(Message message) {
        messages.add(message);
    }

    public synchronized void addSubscriber(String name) {
        subscribers.add(name);
    }

    public synchronized void addClient(String clientName) {
        messagesRead.put(clientName, 0);
    }

    public synchronized int getRead(String clientName) {
        return messagesRead.get(clientName); // returns how many messages have been read by that client
    }

    public synchronized void setRead(String clientName, int newRead) {
        messagesRead.replace(clientName, newRead);
    }

    public synchronized void removeClient(String clientName) {
        messagesRead.remove(clientName);
    }


}

//----------------------------------- Server Member Variables -------------------------------------------------//

    public static ArrayList<Channel> channels = new ArrayList<>();

//----------------------------------- Client Handler -------------------------------------------------//
    static class ClientHandler implements Runnable {

        // login name; null if not set
        private String login;

        private Socket client;
        private PrintWriter out;
        private BufferedReader in;

        public ClientHandler(Socket socket) throws IOException {
            client = socket;
            out = new PrintWriter(client.getOutputStream(), true);
            in = new BufferedReader(
                    new InputStreamReader(client.getInputStream()));
        }

        public void run() {
            try {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {

                    // number of response lines that the client should read
                    int linesToRead = 1;

//----------------------------------- Login -------------------------------------------------//

                    // logging request (+ login if possible) to server console
                    if (login != null)
                        System.out.println(login + ": " + inputLine);
                    else
                        System.out.println(inputLine);

                    // parse request, then try to deserialize JSON
                    Object json = JSONValue.parse(inputLine);
                    Request req;

                    // login request? Must not be logged in already
                    if (login == null &&
                            (req = LoginRequest.fromJSON(json)) != null) {
                        // set login name
                        login = ((LoginRequest) req).getName();

                        // send number of response lines to client
                        out.println(linesToRead); // only 1 line to read (success)

                        // response acknowledging the login request
                        out.println(new SuccessResponse());
                        continue;
                    }
//----------------------------------- Open -------------------------------------------------//

                    // open request. Must be logged in
                    if (login != null &&
                            (req = OpenRequest.fromJSON(json)) != null) {

                        String identity = ((OpenRequest) req).getIdentity();

                        // create a new channel with that name
                        Channel channel = new Channel(identity);
                        // add channel to the collection of channels
                        channels.add(channel);


                        // add client name to messagesRead hashmap --> currently they've read 0 messages
                        channel.addClient(identity);

                        // send number of response lines to client
                        out.println(linesToRead); // only 1 line to read (success)

                        // response acknowledging the post request
                        out.println(new SuccessResponse());
                        continue;

                    }
//----------------------------------- Publish -------------------------------------------------//

                    // Must be logged in and channel also has to be open
                    if (login != null &&
                            (req = PublishRequest.fromJSON(json)) != null &&
                            (channels.size() != 0)) {

                        // retrieve the channel that the client wants to publish to
                        // retrieve the message object
                        String channelName = ((PublishRequest) req).getIdentity();
                        Message message = ((PublishRequest) req).getMessage();


                        // only clients that are subscribed to a channel can publish messages
                        // Get the channel
                        Optional<Channel> channelMatch = channels.parallelStream()
                                .filter(ch -> ch.name.equals(channelName))
                                .findAny();

                        // in case there is no match
                        if (channelMatch.isEmpty()) {
                            out.println(linesToRead);
                            out.println(new ErrorResponse("ERROR: CANNOT FIND CHANNEL"));
                            return;
                        }

                        // check if client is a subscriber to the channel
                        boolean subbed = channelMatch.get().subscribers.contains(login);


                        if (!subbed) { // if the client is not subbed to the channel return an error response
                            out.println(linesToRead);
                            out.println(new ErrorResponse("ERROR: ONLY SUBSCRIBERS CAN PUBLISH MESSAGES"));
                            return;
                        }

                        // add message to channel
                        synchronized (Channel.class) {

                            //add message to channel
                            channelMatch.get().addMessage(message);

                            // append message to file

                            // set the timestamp for that message
                            // The time stamp is simply the index of the message
                            for (Message m : channelMatch.get().messages) {
                                m.setTimestamp(channelMatch.get().messages.indexOf(m) + 1);
                            }

                        }

                        // send number of response lines to client
                        out.println(linesToRead); // only 1 line to read (success)

                        // response acknowledging the post request
                        out.println(new SuccessResponse());
                        continue;
                    }

//----------------------------------- Get -------------------------------------------------//

                    // get request Must be logged in
                    if (login != null &&
                            (req = GetRequest.fromJSON(json)) != null) {

                        // Retrieve the channel identity that the client sent
                        String channelIdentity = ((GetRequest) req).getIdentity();

                        // Get the channel
                        Optional<Channel> channelMatch = channels.parallelStream()
                                .filter(ch -> ch.name.equals(channelIdentity))
                                .findAny();

                        // in case there is no channel with that name
                        if (channelMatch.isEmpty()) {
                            //out.println(linesToRead);
                            out.println(new ErrorResponse("ERROR: CANNOT FIND CHANNEL"));
                            return;
                        }

                        // check if client is a subscriber to the channel
                        boolean subbed = channelMatch.get().subscribers.contains(login);

                        if (!subbed) { // if the client is not subbed to the channel return an error response
                            out.println(linesToRead);
                            out.println(new ErrorResponse("ERROR: ONLY SUBSCRIBERS CAN READ MESSAGES"));
                            return;
                        }

                        boolean channelIsEmpty = false;
                        boolean allMsgsRead = false;

                        List<Message> msgs = null;
                        synchronized (Channel.class) {

                                int msgsRead = channelMatch.get().getRead(login); // how many messages of this channel have been read

                                if (channelMatch.get().messages.size() == 0){
                                    channelIsEmpty = true;
                                }

                                if (msgsRead == channelMatch.get().messages.size()) {
                                    allMsgsRead = true;
                                }
                                else { // there are unread messages

                                    // return a sublist of unread messages
                                msgs = channelMatch.get().messages.subList(msgsRead, channelMatch.get().messages.size());

                                channelMatch.get().setRead(login, channelMatch.get().messages.size());
                                }

                        }
                        if (channelIsEmpty || allMsgsRead) {
                            // no messages to read
                            // send over the total lines that need to be read to client
                            out.println(linesToRead);
                            out.println(new ErrorResponse("ERROR: NO MESSAGES TO READ"));
                        }
                        else {
                            // send over the total lines that need to be read to client
                            // add 1 more for the success response at the end
                            linesToRead = 2;
                            out.println(linesToRead);

                            out.println(new MessageListResponse(msgs));
                            out.println(new SuccessResponse());
                        }
                        continue;
                    }

//----------------------------------- Subscribe -------------------------------------------------//

                    // subscribe request
                    if (login != null &&
                            (req = SubscribeRequest.fromJson(json)) != null) {
                        // subscribe to the channel if they're not already subscribed

                        String channel = ((SubscribeRequest) req).getChannel(); // the channel the client wants to subscribe to (to)
                        String identity = ((SubscribeRequest) req).getIdentity(); // the client's name (from)

                        // get the channel that the client wants to sub to
                        Optional<Channel> channelMatch = channels.parallelStream()
                                .filter(ch -> ch.name.equals(channel))
                                .findAny();
//
                        // in case there is no match
                        if (channelMatch.isEmpty()) {
                            out.println(linesToRead);
                            out.println(new ErrorResponse("ERROR: CANNOT FIND CHANNEL"));
                            return;
                        }
                        else {
                            // check they're already not subbed
                            if (!channelMatch.get().subscribers.contains(identity)) { // not subbed
                                // add name to sub list
                                channelMatch.get().addSubscriber(identity);
                                // add the channel name to the messagesRead hashmap
                                channelMatch.get().addClient(identity);
                            }
                            else { // already subbed
                                out.print(linesToRead);
                                out.print(new ErrorResponse("ERROR: ALREADY SUBBED TO THIS CHANNEL"));
                                return;
                            }
                        }
                        // only a single line to read
                        out.println(linesToRead);
                        out.println(new SuccessResponse());
                        continue;
                    }

//----------------------------------- Unsubscribe -------------------------------------------------//

                    // Unsubscribe request
                    if (login != null &&
                            (req = UnsubscribeRequest.fromJson(json)) != null) {
                        // subscribe to the channel if they're not already subscribed

                        String channel = ((UnsubscribeRequest) req).getChannel();
                        String identity = ((UnsubscribeRequest) req).getIdentity();

                        // get the channel that the client wants to unsub from
                        Optional<Channel> channelMatch = channels.parallelStream()
                                .filter(ch -> ch.name.equals(channel))
                                .findAny();

                        // in case there is no match
                        if (channelMatch.isEmpty()) {
                            out.println(linesToRead);
                            out.println(new ErrorResponse("ERROR: CANNOT FIND CHANNEL"));
                            return;
                        }
                        else {
                            // check they're already not subbed
                            if (channelMatch.get().subscribers.contains(identity)) { // not subbed
                                // remove client name from sub list
                                channelMatch.get().subscribers.remove(identity);
                                // remove their name from the channel's messagesRead hashmap
                                channelMatch.get().removeClient(identity);
                            }
                            else { // already unsubscribed
                                out.print(linesToRead);
                                out.print(new ErrorResponse("ERROR: YOU'RE NOT SUBSCRIBED TO THIS CHANNEL"));
                                return;
                            }
                        }

                        // only a single line to read
                        out.println(linesToRead);
                        out.println(new SuccessResponse());
                        continue;
                    }

//----------------------------------- Quit -------------------------------------------------//

                    // quit request? Must be logged in;
                    // send quit response because client needs to receive a response to avoid crashing
                    if (login != null && QuitRequest.fromJSON(json) != null) {
                        out.println(linesToRead);
                        out.println(new QuitResponse());
                        in.close();
                        out.close();
                        return;
                    }

//----------------------------------- Error -------------------------------------------------//

                    // error response acknowledging illegal request
                    // send over number of lines to client
                    out.println(linesToRead);
                    out.println(new ErrorResponse("ERROR: ILLEGAL REQUEST"));
                }
            } catch (IOException e) {
                System.out.println("Exception while connected");
                System.out.println(e.getMessage());
            }
        }
    }

    public static void main(String[] args) {


        int portNumber = 12345;

        try (
                ServerSocket serverSocket = new ServerSocket(portNumber);
        ) {

            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(new ClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            System.out.println("Exception listening for connection on port " +
                    portNumber);
            System.out.println(e.getMessage());
        }
    }
}
