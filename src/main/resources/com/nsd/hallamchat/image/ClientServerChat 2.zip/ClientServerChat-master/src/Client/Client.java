package Client;

import Message.Message;
import Server.*;
import org.json.simple.JSONValue;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Client {


    private static String username;


    public static void main(String[] args) throws IOException {

        String hostName = "localhost";
        int portNumber = 12345;

        try (
                Socket socket = new Socket(hostName, portNumber);
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream()));
                BufferedReader stdIn = new BufferedReader(
                        new InputStreamReader(System.in))
        ) {
            String userInput;
            while ((userInput = stdIn.readLine()) != null) {
                // Parse user and build request
                Request req;


                Scanner sc = new Scanner(userInput);
                try {
                    switch (sc.next()) {
                        case "login": {
                            username = sc.skip(" ").nextLine(); // this sets the username which can be used for all other requests
                            req = new LoginRequest(username);
                            break;
                        }
                        case "open":{
                            req = new OpenRequest(username);
                            break;
                        }
                        case "publish": {
                            String channel = sc.skip(" ").next();
                            String message = sc.skip(" ").nextLine();
                            req = new PublishRequest(channel, username, message);
                            break;
                        }
                        case "get":
                            req = new GetRequest(sc.skip(" ").nextLine());
                            break;
                        case "sub":
                            req = new SubscribeRequest(username, sc.skip(" ").nextLine());
                            break;
                        case "unsub":
                            req = new UnsubscribeRequest(username, sc.skip(" ").nextLine());
                            break;
                        case "quit":
                            req = new QuitRequest();
                            break;
                        default:
                            System.out.println("ILLEGAL COMMAND");
                            continue;
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("ILLEGAL COMMAND");
                    continue;
                }

                // Send request to server
                out.println(req);

                // first line from the server is always the number of lines to read next
                int responseLines = Integer.parseInt(in.readLine());

                // Read server response; terminate if null (i.e. server quit)
                String serverResponse;

                for (int i = 0; i < responseLines; i++) {

                    if ((serverResponse = in.readLine()) == null)
                        break;

                    // Parse JSON response, then try to deserialize JSON
                    Object json = JSONValue.parse(serverResponse);
                    Response resp;

                    // Try to deserialize a success response
                    if (SuccessResponse.fromJSON(json) != null)
                        continue;

                    // Try to deserialize a list of messages
                    if ((resp = MessageListResponse.fromJSON(json)) != null) {
                        for (Message m : ((MessageListResponse)resp).getMessages())
                            System.out.println(m);
                        continue;
                    }

                    // Try to deserialize an error response
                    if ((resp = ErrorResponse.fromJSON(json)) != null) {
                        System.out.println(((ErrorResponse)resp).getError());
                        continue;
                    }

                    // Try to deserialize a Quit response
                    if ((resp = QuitResponse.fromJSON(json)) != null) {
                        System.out.println((("Session ended")));
                        // close the socket
                        socket.close();
                        continue;
                    }

                    // Not any known response
                    System.out.println("PANIC: " + serverResponse +
                            " parsed as " + json);
                    break;
                }
            }
        } catch (UnknownHostException e) {
            System.err.println("Don't know about host " + hostName);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Couldn't get I/O for the connection to " +
                    hostName);
            System.exit(1);
        }
    }
}
